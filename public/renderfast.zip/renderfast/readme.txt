=== RenderFast — Prerender for SEO & AI ===
Contributors: renderfast
Tags: seo, prerender, javascript, crawler, ai, googlebot
Requires at least: 5.5
Tested up to: 6.6
Requires PHP: 7.4
Stable tag: 1.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Serve search engines and AI crawlers fully-rendered HTML so JavaScript-heavy WordPress sites get indexed perfectly. Real visitors are untouched.

== Description ==

RenderFast detects search-engine and AI crawlers (Googlebot, Bingbot, GPTBot, ClaudeBot, PerplexityBot, social unfurlers, and more) and serves them prerendered HTML from the RenderFast service. Human visitors are passed straight through to your normal WordPress site — zero impact on their experience.

**Features**
* One-click connect — log in with your RenderFast email & password, no key copying.
* Automatic domain registration with your account.
* Live usage dashboard right inside WordPress (plan, monthly renders, this site's renders).
* Enable/disable prerendering with a toggle.
* Built-in "Test prerendering" button.

== Installation ==

1. In WordPress: Plugins → Add New → Upload Plugin → choose `renderfast.zip` → Install → Activate.
2. Go to the new **RenderFast** menu item.
3. Don't have an account? Click **Sign up on RenderFast**, create a free account, then return.
4. Log in with your RenderFast email & password. Your domain is registered automatically.
5. Done — crawlers now receive prerendered HTML. Use **Test prerendering** to confirm.

== Frequently Asked Questions ==

= Does this slow down my site for visitors? =
No. Only crawler User-Agents are intercepted; real visitors get your normal site.

= Where do renders happen? =
On RenderFast's servers (Cloudflare Browser Rendering). The plugin only forwards crawler requests.

== Changelog ==

= 1.0.0 =
* Initial release: prerender middleware, in-dashboard login/sign-up, usage stats, test tool.
